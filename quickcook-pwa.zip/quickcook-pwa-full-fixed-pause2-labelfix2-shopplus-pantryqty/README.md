# QuickCook — Full Prototype (Fixed)
Serve over HTTP(S) for Materialize + Service Worker to work. Use:
- Python: `python -m http.server 8080`
Then visit `http://localhost:8080/quickcook-pwa-full-fixed/`.
